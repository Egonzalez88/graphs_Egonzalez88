# Graph Algorithms Library

This library implements Dijkstra's shortest path algorithm in Python.
It is designed as a reusable Python package for working with graphs.

## Installation

pip install graphs_Egonzalez88